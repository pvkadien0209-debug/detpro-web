# Quy trình sản xuất chuỗi bài + video tiết kiệm token (#251–#252)

> Anh DIENPHAM dặn ngày 28/10/2026: "Lưu lại cách thức để đỡ tốn token, video vẫn ổn, đạt được các điều tôi đã chốt."
> Rút ra từ đợt #249 (10 chuỗi A1, 60 bài): khoảng 9–10 triệu token, mỗi nhóm con 170–340 nghìn. Phần lớn là ĐỌC LẠI tài liệu, không phải viết.

## 1. Những điều đã chốt — giữ nguyên khi tiết kiệm

| Chốt | Nội dung | Ở đâu |
|---|---|---|
| #088 | Bài dựa trên nguồn thật, không bịa số; ý không có nguồn ghi "kinh nghiệm chung" | UNIT-SPEC.md |
| #136 | Hạt nhân video: Đét đứng trái + một bảng trắng 10 ô, một dòng thời gian, khung ảnh nhân vật, tô vàng đúng lúc đọc, "Khoan đã!", khép vòng, câu đố, kết | HAT-NHAN-KICH-BAN.md |
| #252 (cách A) | Bảng trắng là xương sống, khoảng 50–60% thời lượng; mỗi video chen **5–8 cảnh toàn màn** bằng module khác (mở đầu, so sánh, số liệu, danh sách, nhân quả, hiểu lầm, kết). **Không lặp**: không trùng module trong video, không trùng video trước của cùng chuỗi, ưu tiên module ít dùng → dần phủ hết kho 126 module | `VID\tools\da-dang-hoa\chon-module.mjs` |
| #249 | Cấp độ A1/B1/C1: đáp án 6–10 / 10–16 / 16–25 từ; lời video A1 mỗi câu ≤ 12 từ | check_unit.py, QUY-CHUAN |
| #137 | Giọng Kokoro trên máy anh; anh tự render | bat |

## 2. Cách làm tiết kiệm (theo thứ tự hiệu quả)

1. **Một nhóm con cho một chuỗi, làm từ đầu tới cuối** (bài → video → TikTok). Tìm nguồn MỘT lần, ghi `noi-dung/nguon/<chuỗi>.md` (link + ý chính), các bước sau đọc tệp này thay vì tìm lại.
2. **Không cho nhóm con đọc tài liệu dài.** Thay bằng tờ tóm tắt 2–3 KB (luật + đường dẫn) và lệnh in đúng phần cần:
   - `node tools/da-dang-hoa/chon-module.mjs <bài>` in kế hoạch module + mẫu dữ liệu CHỈ của module được chọn (không đọc cả MODULE-REF 60 KB).
   - Bài mẫu: chỉ xem 1 bài, không 3.
3. **Kịch bản viết bằng "dàn ý truyện" 3–5 KB, máy dựng phần còn lại** (#251 — công cụ `tools/kich-ban/dung-tu-dan-y.mjs`, đang làm): nhân vật, dòng thời gian, lời từng ô, loại nhịp → máy tự xếp bảng 10 ô, camera, mốc chữ theo lời đọc, câu đố đúng thứ tự, chọn module xoay vòng (cách A), tự kiểm. Giữ khuôn hạt nhân cho mọi video; khác nhau ở module và truyện.
4. **Lỗi cơ học để máy sửa**, không để nhóm con sửa tay nhiều vòng: chia đều cột đáp án, đếm từ đáp án, dời mốc chữ theo lời, cắt phụ đề quá dài.
5. **Chia mô hình theo việc:** Opus viết nội dung bài và dựng truyện; Sonnet (rẻ hơn) làm thoại TikTok, áp module đa dạng, sửa lỗi máy kiểm.
6. **TikTok:** mặc định dùng lời có sẵn của bài (cùng giọng, khớp video bài học); chỉ viết lại thoại cho bài anh chọn.
7. **Chạy theo đợt ≤ 10 nhóm con** để không chạm giới hạn 5 giờ; mỗi nhóm một thư mục nháp riêng (`/tmp/.../<chuỗi>/`) để không ghi đè nhau.
8. **Sửa tệp bằng script nhỏ** (đọc JSON → đổi → ghi), không in cả tệp 30–60 KB ra màn hình.

## 3. Cửa kiểm chất lượng (bắt buộc, không bỏ khi tiết kiệm)

- Bài: `python check_unit.py --luu-y units/<chuỗi>/<bài>.json` → LỖI 0.
- Video: `node tools/check-script.mjs <kịch bản> --units=<units> --text` → LỖI 0, thời lượng 5–8 phút.
- TikTok: `node tools/tiktok/kiem-thoai.mjs <bài>` → OK.
- Độ đa dạng: `node tools/da-dang-hoa/chon-module.mjs --so-dem` → số module chưa dùng giảm dần qua mỗi đợt.

## 4. Ước lượng

| Việc | #249 (cách cũ) | Cách mới (ước) |
|---|---|---|
| 1 bài viết + 40 câu | ~40 nghìn token | ~25 nghìn (nguồn dùng chung theo chuỗi) |
| 1 kịch bản video | ~95 nghìn | ~20–30 nghìn (dàn ý + máy dựng) |
| 1 thoại TikTok | ~35 nghìn (Opus) | ~10 nghìn (lời có sẵn) hoặc ~30 nghìn Sonnet |

Ghi nhận: #251 tiết kiệm token · #252 cách A đa dạng module.

## 5. Bổ sung (anh "ok" 28/10/2026)

- **Giao tệp bằng một gói zip + .bat giải nén** (`00-giai-nen-goi-...bat` trong thư mục BAT của việc), không chép từng tệp lên máy anh — chép từng tệp tốn ~10.000 token mỗi 50 tệp.
- **Nhóm con chỉ báo lại 1–2 dòng** (kết quả kiểm + điều cần anh xem), không liệt kê dài.
- **Mỗi việc lớn mở một phiên mới**, tránh kéo dài một phiên (phiên dài thì mỗi bước đều đắt hơn vì phải gửi lại cả ngữ cảnh).
